```php
<?php
if (!empty($_POST["btnregistrar"])) {
    if (
        !empty($_POST["nombre"]) &&
        !empty($_POST["apellido"]) &&
        !empty($_POST["dni"]) &&
        !empty($_POST["fecha"]) &&
        !empty($_POST["email"])
    ) {
        $nombre = $_POST["nombre"];
        $apellido = $_POST["apellido"];
        $dni = $_POST["dni"];
        $fecha = $_POST["fecha"];
        $email = $_POST["email"];

        $stmt = $conexion->prepare("INSERT INTO PERSONAS (nombre, apellido, cedula, fecha_nacimiento, correo) 
                                    VALUES (?, ?, ?, ?, ?)");
        
        $stmt->bind_param("sssss", $nombre, $apellido, $dni, $fecha, $email);
        
        if ($stmt->execute()) {
            echo '<div class="alert alert-success" role="alert">
                    Persona registrada correctamente.
                  </div>';
        } else {
            echo '<div class="alert alert-danger" role="alert">
                    Persona no registrada correctamente.
                  </div>';
        }

        $stmt->close();
    } else {
        echo '<div class="alert alert-danger" role="alert">
                Alguno de los campos está vacío.
              </div>';
    }
}
?>
```