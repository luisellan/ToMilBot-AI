```php
<?php
include "../../models/conexion.php";
$data = json_decode(file_get_contents('php://input'), true);

$nombre = mysqli_real_escape_string($conexion, $data['nombre']);
$cantidad = (int)$data['cantidad'];
$precio = (float)$data['precio'];

$sql = "INSERT INTO productos (nombre, cantidad, precio) VALUES ('$nombre', $cantidad, $precio)";

if ($conexion->query($sql) === TRUE) {
    echo json_encode(["message" => "Producto guardado exitosamente"]);
} else {
    echo json_encode(["message" => "Error al guardar producto: " . $conexion->error]);
}

?>
```