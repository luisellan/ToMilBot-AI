```php
<?php
    if (!empty($_GET["id"])) {
        $id = $_GET["id"];

        $sql = $conexion->query("DELETE FROM PERSONAS WHERE ID = " . intval($id));
        if ($sql) {
            echo '<div class="alert alert-success" role="alert">
            Persona eliminada correctamente.
          </div>';
        } else {
            echo '<div class="alert alert-danger" role="alert">
            Persona no eliminada correctamente.
          </div>';
        }
    }
?>
```