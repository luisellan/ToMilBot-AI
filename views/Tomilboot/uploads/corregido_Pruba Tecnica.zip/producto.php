```php
<?php
include "../../models/conexion.php";

$id = $_GET["id"];

$sql = $conexion->query("SELECT * FROM productos WHERE id = $id");

$producto = $sql->fetch_assoc();

echo json_encode($producto);
?>
```
