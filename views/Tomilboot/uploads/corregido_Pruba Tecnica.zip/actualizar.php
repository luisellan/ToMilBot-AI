```php
<?php
include "../../models/conexion.php";
$data = json_decode(file_get_contents('php://input'), true);

$id = $conexion->real_escape_string($data['id']);
$nombre = $conexion->real_escape_string($data['nombre']);
$cantidad = $conexion->real_escape_string($data['cantidad']);
$precio = $conexion->real_escape_string($data['precio']);

$sql = "UPDATE productos SET nombre='$nombre', cantidad='$cantidad', precio='$precio' WHERE id='$id'";

if ($conexion->query($sql) === TRUE) {
    echo json_encode(["message" => "Producto actualizado exitosamente"]);
} else {
    echo json_encode(["message" => "Error al actualizar producto: " . $conexion->error]);
}

$conexion->close();
?>
```