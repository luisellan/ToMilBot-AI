```javascript
function cargarProductos() {
    fetch('controller/Ecommerce/productos.php')
        .then(response => response.json())
        .then(data => {
            let tableBody = document.querySelector('#productosTable tbody');
            tableBody.innerHTML = '';

            data.forEach(producto => {
                let row = document.createElement('tr');
                row.innerHTML = `
                    <td>${producto.id}</td>
                    <td>${producto.nombre}</td>
                    <td>${producto.precio}</td>
                    <td>${producto.cantidad}</td>
                    <td>
                        <button onclick="editarProducto(${producto.id})">Editar</button>
                        <button onclick="eliminarProducto(${producto.id})">Eliminar</button>
                    </td>
                `;
                tableBody.appendChild(row);
            });
        });
}

document.getElementById('formProducto').addEventListener('submit', function (e) {
    e.preventDefault();

    let id = document.getElementById('id').value;
    let nombre = document.getElementById('nombre').value;
    let cantidad = document.getElementById('cantidad').value;
    let precio = document.getElementById('precio').value;

    let url = id ? 'controller/Ecommerce/actualizar.php' : 'controller/Ecommerce/guardar.php';

    let data = {
        id: id,
        nombre: nombre,
        cantidad: cantidad,
        precio: precio
    };

    fetch(url, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
        .then(response => response.json())
        .then(result => {
            alert(result.message);
            cargarProductos();
            document.getElementById('formProducto').reset();
            document.getElementById('id').value = '';
        })
});


function editarProducto(id) {
    fetch('controller/Ecommerce/producto.php?id=' + id)
        .then(response => response.json())
        .then(producto => {
            document.getElementById('id').value = producto.id;
            document.getElementById('nombre').value = producto.nombre;
            document.getElementById('cantidad').value = producto.cantidad;
            document.getElementById('precio').value = producto.precio;
        });
}

function eliminarProducto(id) {
    if (confirm('Estas seguro de eliminar este producto')) {
        fetch('controller/Ecommerce/eliminar.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ id: id })
        })
            .then(response => response.json())
            .then(result => {
                alert(result.message);
                cargarProductos();
            })
    }
}


cargarProductos();
```