```php
<?php
if (!empty($_POST["btnactualizar"])) {
    if (
        !empty($_POST["id"]) &&
        !empty($_POST["nombre"]) &&
        !empty($_POST["apellido"]) &&
        !empty($_POST["dni"]) &&
        !empty($_POST["email"])
    ) {
        $id = $_POST["id"];
        $nombre = $_POST["nombre"];
        $apellido = $_POST["apellido"];
        $dni = $_POST["dni"];
        $email = $_POST["email"];

        $stmt = $conexion->prepare("UPDATE PERSONAS SET nombre = ?, apellido = ?, cedula = ?, correo = ? WHERE id = ?");

        $stmt->bind_param("ssssi", $nombre, $apellido, $dni, $email, $id);

        if ($stmt->execute()) {
            session_start();
            $_SESSION['mensaje'] = 'Persona Actualizada correctamente.';
            header("Location: index.php");
            exit();
        } else {
            echo '<div class="alert alert-danger" role="alert">Persona no Actualizada correctamente.</div>';
        }

        $stmt->close();
    } else {
        echo '<div class="alert alert-danger" role="alert">Alguno de los campos está vacío.</div>';
    }
}
?>
```