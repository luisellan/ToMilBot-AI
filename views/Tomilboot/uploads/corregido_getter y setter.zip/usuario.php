```php
<?php
    require_once("ClassUsuario.php");
    $objUsuario = new Usuario("Andres Cardona","andres@info.com","Admin");
    $objUsuario1 = new Usuario("Andresa","andresa@info.com","Cliente");
    echo Usuario::$strEstado;


    echo $objUsuario->getPerfil();
    echo $objUsuario1->getPerfil();
    echo $objUsuario1->setCambiarClave("123456");

    echo $objUsuario1->getPerfil();

?>
```