```php
<?php
include "../../models/conexion.php";

$sql = $conexion->query("SELECT * FROM productos");

$productos = array();

while ($producto = $sql->fetch_assoc()) {
    $productos[] = $producto;
}

header('Content-Type: application/json');
echo json_encode($productos);
?>
```
