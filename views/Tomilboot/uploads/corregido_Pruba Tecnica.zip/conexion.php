```php
<?php
$host = "localhost";
$usuario = "root";
$password = "";
$base_datos = "crud_php";

$conexion = new mysqli($host, $usuario, $password, $base_datos);

if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

if (!$conexion->set_charset("utf8mb4")) {
    die("Error al establecer el conjunto de caracteres: " . $conexion->error);
}
?>
```